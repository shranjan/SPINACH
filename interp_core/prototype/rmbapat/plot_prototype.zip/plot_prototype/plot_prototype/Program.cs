﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;


namespace plot_prototype
{
    class Program
    {
        static void Main(string[] args)
        {

            node n1 = new node();
            plot2D p1 = new plot2D();
            
            Matrix value = new Matrix();
            value.setElements(1);
           value.setElements(2);
          value.setElements(3);
            value.setElements(4);
            Console.Write("\n The data for plot2D command is : \n");
            List<int> input_elements = value.getElements();
            for (int i = 0; i < input_elements.Count; i++)
            {
                Console.Write(input_elements[i]);
            }
            Console.Write("\n");
            
            n1.lchild = null;
            n1.rchild = null;

            node n2 = new node();
            n2.value="a";
            Console.Write("\n The second parameter of plot2D command is title : ");
            p1.setTitle("a");
            string input_title = p1.getTitle();
            Console.Write(input_title);
            Console.Write("\n");
            n2.lchild = null;
            n2.rchild = null;

            node n3 = new node();
            n3.value = "plot2D";
            p1.setTitle("plot2D");
            n3.lchild = n1;
            n3.rchild = n2;
            
        }
    }
}
