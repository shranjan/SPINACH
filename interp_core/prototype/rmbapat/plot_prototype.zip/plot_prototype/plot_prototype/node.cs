﻿////////////////////////////////////////////////////////////////////////
// node.cs : holds the AST structure                                  //
// version: 1.0                                                       //
// author: Rucha Bapat (rmbapat@syr.edu)                              //
// language: c#                                                       //
////////////////////////////////////////////////////////////////////////

//using Matrix;
using System.Collections.Generic;

public class node
{
    public string value;
    public node lchild;
    public node rchild;

    public node() { }

    public void setValue(string val) { value = val; }
    public string getValue() { return value; }

    public void setLchild(node left) { lchild = left; }
    public node getLchild() { return lchild; }

    public void setRchild(node right) { rchild = right; }
    public node getRchild() { return rchild; }

}
