﻿////////////////////////////////////////////////////////////////////////
// plot.cs : holds the data needed for plotting data                  //
// version: 1.0                                                       //
// author: Rucha Bapat (rmbapat@syr.edu)                              //
// language: c#                                                       //
////////////////////////////////////////////////////////////////////////

//using Matrix;
using System.Collections.Generic;

public abstract class plot
{
    public abstract List<int> getData();
    public abstract void setData(int intValue);

    public abstract string getTitle();
    public abstract void setTitle(string titleValue);
}
/*public class plot
{
    Matrix data;
    string title;


    public List<int> getData() { return data.getElements(); }
    public void setData(int dvalue) { data.setElements(dvalue); }

    public string getTitle() { return title; }
    public void setTitle(string tvalue) { title = tvalue; }

}*/