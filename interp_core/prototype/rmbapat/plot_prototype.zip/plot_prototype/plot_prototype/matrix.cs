﻿//////////////////////////////////////////////////////////////////////////////////////////
// Matrix.cs: Matrix data structure                                                     //
// version: 1.0                                                                         //
// author: Rucha Bapat (rmbapat@syr.edu)                                                //
// language: C#                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////

using System.Collections.Generic;   // to include List

public class Matrix{

   int row;
    int col;
	List<int> input;

	public int getRow() { return row; }
    public void setRow(int rvalue) { row = rvalue; }

    public int getCol() { return col; }
    public void setCol(int cvalue) { col = cvalue; }

    public List<int> getElements() { return input; }
    public void setElements(int ivalue) { input.Add(ivalue); }

    public Matrix()
    { input = new List<int>(); }

    /*Element * getLhs();
    void setLhs(Element * lhs);

	 Element * getRow();
  void setRow(Element * row);

   Element * getCol();
  void setCol(Element * col);

  std::vector<Element *> getElements();
  void setElements(Element * elements);*/

}
