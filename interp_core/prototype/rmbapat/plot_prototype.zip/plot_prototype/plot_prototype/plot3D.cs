﻿////////////////////////////////////////////////////////////////////////
// plot3D.cs : holds the data needed for plotting 3D data             //
// version: 1.0                                                       //
// author: Rucha Bapat (rmbapat@syr.edu)                              //
// language: c#                                                       //
////////////////////////////////////////////////////////////////////////
//using Matrix;
using System.Collections.Generic;

public class plot3D : plot
{
    Matrix data;
    string title;
    string mode;

    public override List<int> getData() { return data.getElements(); }
    public override void setData(int dvalue) { data.setElements(dvalue); }

    public override string getTitle() { return title; }
    public override void setTitle(string tvalue) { title = tvalue; }

    public string getMode() { return mode; }
    public void setMode(string mvalue) { mode = mvalue; }

}