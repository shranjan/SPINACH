﻿////////////////////////////////////////////////////////////////////////
// subplot3D.cs : holds the data needed for plotting 3D data          //
// version: 1.0                                                       //
// author: Rucha Bapat (rmbapat@syr.edu)                              //
// language: c#                                                       //
////////////////////////////////////////////////////////////////////////

//using Matrix;
using System.Collections.Generic;


public class subplot3D : plot
{
    Matrix data;
    string title;
    int row;
    int col;
    string mode;

    public override List<int> getData() { return data.getElements(); }
    public override void setData(int dvalue) { data.setElements(dvalue); }

    public override string getTitle() { return title; }
    public override void setTitle(string tvalue) { title = tvalue; }

    public void setRow(int rowValue) { row = rowValue; }
    public int getRow() { return row; }

    public void setCol(int colValue) { col = colValue; }
    public int getCol() { return col; }

    public void setMode(string modeValue) { mode = modeValue; }
    public string getMode() { return mode; }

}