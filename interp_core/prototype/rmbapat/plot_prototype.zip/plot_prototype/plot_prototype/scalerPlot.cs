﻿////////////////////////////////////////////////////////////////////////
// scalerPlot.cs : holds the data needed for plotting scaler data     //
// version: 1.0                                                       //
// author: Rucha Bapat (rmbapat@syr.edu)                              //
// language: c#                                                       //
////////////////////////////////////////////////////////////////////////


public class scalerPlot
{
    int data;
    string title;

    public int getData() { return data; }
    public void setData(int dvalue) { data = dvalue; }

    public string getTitle() { return title; }
    public void setTitle(string tvalue) { title = tvalue; }

}