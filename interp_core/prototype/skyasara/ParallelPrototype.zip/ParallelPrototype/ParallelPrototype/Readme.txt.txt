For the prototype, two statements are being considered in the parallel-for loop,
say a[i]=b[i]+c[i], and a[i]=b[i]*c[i].
The statements will be sent in the form of inorder and preorder traversal in the form
of a character array, first character for each traversal being 'i' and 'p'
to differentiate between inorder and preorder respectively.
While the data will be sent in the form of xml representation. 
xml file is matformat.xml which gets created in the debug folder now(current dir).