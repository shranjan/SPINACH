////////////////////////////////////////////////////////////////////////
// AdditionOperationElement.cs: holds the data needed for an addition 
//  operation.
// 
// version: 1.0
// description: part of the interpreter example for the visitor design
//  pattern.
// author: Chetan Thawani (cthawani@syr.edu)
// source: Phil-Pratt-Szeliga
// language: C# .Net 3.5
////////////////////////////////////////////////////////////////////////

// class for performing addition operation involving elements of AST's
public class AdditionOperationElement : Element {

  Element mLhs; //left element
  Element mRhs;  //right element

//this function visits the addition operation element of AST.
  public override void Accept(Visitor visitor){
    visitor.VisitAdditionOperationElement(this);
  }

//get the left element of AST
  public Element getLhs() { return mLhs; }
//set the left element of AST to some value
  public void setLhs(Element lhs) { mLhs = lhs; }
//get right element of AST
  public Element getRhs() { return mRhs; }
//set right element of AST
  public void setRhs(Element rhs) { mRhs = rhs; }
}
