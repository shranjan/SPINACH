////////////////////////////////////////////////////////////////////////
// PrettyPrintVisitor.cs: demonstrates printing the syntax tree in 
//  a difference source language than the input for the Interp language.
// 
// version: 1.0
// description: part of the interpreter example for the visitor design
//  pattern.
// author: Chetan Thawani (cthawani@syr.edu)
// source: phil pratt-szeliga (pcpratts@syr.edu)
// language: C# .Net 3.5
////////////////////////////////////////////////////////////////////////
using System;
using System.Collections;
using System.Collections.Generic;

public class PrettyPrintVisitor : Visitor
{

    public override void VisitVariableElement(VariableElement element)
    {
        Console.Write("var:" + element.getText() + " ");
    }
    public override void VisitIntegerElement(IntegerElement element)
    {
        Console.Write("int:" + element.getText() + " ");
    }
    public override void VisitAssignmentOperationElement(AssignmentOperationElement element)
    {
        VisitElement(element.getLhs());
        Console.Write(":= ");
        VisitElement(element.getRhs());
        Console.WriteLine(";");
    }
    public override void VisitAdditionOperationElement(AdditionOperationElement element)
    {
        VisitElement(element.getLhs());
        Console.Write("+ ");
        VisitElement(element.getRhs());
        Console.Write(" ");
    }

    public override void VisitMultiplicationOperationElement(MultiplicationOperationElement element)
    {
        VisitElement(element.getLhs());
        Console.Write("* ");
        VisitElement(element.getRhs());
        Console.Write(" ");
    }

    public override void VisitSubtractionOperationElement(SubtractionOperationElement element)
    {
        VisitElement(element.getLhs());
        Console.Write("- ");
        VisitElement(element.getRhs());
        Console.Write(" ");
    }

    public override void VisitPrintOperationElement(PrintOperationElement element)
    {
        Console.Write("function:print ");
        VisitElement(element.getChildElement());
        Console.WriteLine(";");
    }

    public override void VisitMatrixElement(MatrixElement element)
    {
        VisitElement(element.getLhs());
        Console.Write(":= ");
        //VisitElement(element.getRhs());

        Console.WriteLine(" row = " + element.getRow() + "\n col = " + element.getCol());
        List<int> al = new List<int>();
        al = element.values; 

        if ((element.getCol() * element.getRow()) != al.Count)
        {
            Console.WriteLine("\n Your matrix is incorrect");
            return;
        }

        int i = 0;
        for (int x = 0; x < element.getRow(); x++)
        {
            for (int y = 0; y < element.getCol(); y++)
            {
                Console.Write(" " + al[i++]);
            }
            Console.Write("\n");
        }
    }
}