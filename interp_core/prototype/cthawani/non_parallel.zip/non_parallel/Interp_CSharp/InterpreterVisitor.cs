////////////////////////////////////////////////////////////////////////
// InterpreterVisitor.cs: Implements a vistor that interprets the 
//  syntax tree.
// 
// version: 1.0
// description: part of the interpreter example for the visitor design
//  pattern.
// author: Chetan Thawani (cthawani@syr.edu)
// source: phil pratt-szeliga (pcpratts@syr.edu)
// language: C# .Net 3.5
////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Collections;


public class InterpreterVisitor : Visitor
{

    Hashtable mVariableMap; //hashtable of scalar variables
    Hashtable matVariableMap; //hashtable of matrix variables
    Stack<int> mStack; //stack of integers
    Stack<MatrixElement> matStack; //stack of matrix elements

    public InterpreterVisitor() //constructor for interpretervisitor class
    {
        mVariableMap = new Hashtable();
        matVariableMap = new Hashtable();
        mStack = new Stack<int>();
        matStack = new Stack<MatrixElement>();
    }
    //function performing action when visiting variable element
    public override void VisitVariableElement(VariableElement element)
    {
        if (mVariableMap.ContainsKey(element.getText()))
        {
            int element_value = (int)mVariableMap[element.getText()];
            mStack.Push(element_value);
        }
        else if (matVariableMap.ContainsKey(element.getText()))
        {
            MatrixElement element_value = (MatrixElement)mVariableMap[element.getText()];
            matStack.Push(element_value);
        }
        else
        {
            //lets assume that the syntax has been checked for this example because I don't like the exception
            //propegation that will happen if I throw here
            //throw new Exception("Variable " + element.getText() + " not defined.");
        }
    }
    //function performing action on integer element
    public override void VisitIntegerElement(IntegerElement element)
    {
        int element_value = int.Parse(element.getText());
        mStack.Push(element_value);
    }
    //function performing action on assignment operation element
    public override void VisitAssignmentOperationElement(AssignmentOperationElement element)
    {
        String variable_name = element.getLhs().getText();

        Element rhs = element.getRhs();
        VisitElement(rhs);
        int result = mStack.Pop();
        mVariableMap[variable_name] = result;
    }
    //function performing action on addition operation element
    public override void VisitAdditionOperationElement(AdditionOperationElement element)
    {
        VisitElement(element.getLhs());
        VisitElement(element.getRhs());
        int rhs = mStack.Pop();
        int lhs = mStack.Pop();
        int result = rhs + lhs;
        mStack.Push(result);
    }
    //function performing action on substraction operation element
    public override void VisitSubtractionOperationElement(SubtractionOperationElement element)
    {
        VisitElement(element.getLhs());
        VisitElement(element.getRhs());
        int rhs = mStack.Pop();
        int lhs = mStack.Pop();
        int result = lhs - rhs;
        mStack.Push(result);
    }
    //function performing action on multiplication operation element
    public override void VisitMultiplicationOperationElement(MultiplicationOperationElement element)
    {
        VisitElement(element.getLhs());
        VisitElement(element.getRhs());
        int rhs = mStack.Pop();
        int lhs = mStack.Pop();
        int result = rhs * lhs;
        mStack.Push(result);
    }
    //function performing action on print operation element
    public override void VisitPrintOperationElement(PrintOperationElement element)
    {
        VariableElement velement = (VariableElement)element.getChildElement();

        if (mVariableMap.ContainsKey(velement.getText()))
        {
            VisitElement(element.getChildElement());
            int result = mStack.Pop();
            Console.WriteLine(result.ToString());
        }
        else if (matVariableMap.ContainsKey(velement.getText()))
        {
            MatrixElement e = new MatrixElement();
            e = (MatrixElement)matVariableMap[velement.getText()];
            
            int x, y; //, i = 0;

            for (x = 0; x < e.getRow(); x++)
            {
              for (y = 0; y < e.getCol(); y++)
              {
                Console.WriteLine(" " + e.mat[x][y]);
              }              
            }               
	     }
	     else
	     {
	        Console.WriteLine("Variable not found!");  
	     }     
    }
    //function performing action on matrix element
    public override void VisitMatrixElement(MatrixElement element)
    {
        String variable_name = element.getLhs().getText();

        Element rhs = element.getRhs();
        VisitElement(rhs);
        int result = mStack.Pop();
        mVariableMap[variable_name] = result;

    }
}