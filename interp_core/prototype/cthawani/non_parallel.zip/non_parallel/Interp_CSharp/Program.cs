﻿////////////////////////////////////////////////////////////////////////
// Program.cs: demonstrates the interpreter for the Interp language.
// 
// version: 1.0
// description: part of the interpreter example for the visitor design
//  pattern.
// author: Chetan Thawani (cthawani@syr.edu)
// source: phil pratt-szeliga (pcpratts@syr.edu)
// language: C# .Net 3.5
////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Antlr.Runtime;

namespace Interp_CSharp
{
    class Program
    {
        InterpreterVisitor interp_visitor = new InterpreterVisitor();
        PrettyPrintVisitor print_visitor = new PrettyPrintVisitor();

        public void VisitLine(String line)
        {
            ANTLRStringStream string_stream = new ANTLRStringStream(line);
            InterpLexer lexer = new InterpLexer(string_stream);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            InterpParser parser = new InterpParser(tokens);
            try
            {
                InterpParser.program_return program = parser.program();
                List<Element> elements = program.ret;
                for (int i = 0; i < elements.Count; i++)
                {
                    Element curr = elements[i];
                    curr.Accept(print_visitor);
                    curr.Accept(interp_visitor);
                }
            }
            catch (RecognitionException e)
            {
                Console.WriteLine(e.Message);
            }

        }

        public void RunEvalLoop()
        {
            while (true)
            {
                Console.Write("Interp> ");
                String line = Console.ReadLine();
                if (line == "reset")
                    interp_visitor = new InterpreterVisitor();
                else
                    VisitLine(line);
            }
        }

#if(TEST_MAIN1)

      public static void Main(String[] args)
      {
         Program theprogram = new Program();

         //first demonstrate visiting premade line.
         theprogram.VisitLine("mv = 1 + 2; var = mv + 3; print var;");
                   
         int r1, r2, c1, c2, x, y, z;
         MatrixElement a, b, c;
         
         ///////////////////////////////////////////////////////////////////////
         a = new MatrixElement();
         a.setRow(2);
         a.setCol(3);
          r1 = a.getRow();
          c1 = a.getCol();
         a.setValues(1); a.setValues(2); a.setValues(3); a.setValues(4); a.setValues(5); a.setValues(6);
         Console.WriteLine("\n Matrix \"a\" with row = " + r1 + " column = " + c1);
         a.setMatrix();   

         b = new MatrixElement();
         b.setRow(2);
         b.setCol(3);
          r2 = b.getRow();
          c2 = b.getCol();        
         b.setValues(11); b.setValues(12); b.setValues(13); 
         b.setValues(14); b.setValues(5);  b.setValues(16);
         Console.WriteLine("\n Matrix \"b\" with row = " + r2 + " column = " + c2);         
         b.setMatrix();  

         Console.WriteLine(" Adding matrices a & b [c = a + b;]");
        
         c = new MatrixElement();
        
        if (r1 == r2 && c1 == c2)
        {
            c.setRow(r1);
            c.setCol(c1);

            for (x = 0; x < r1; x++)
            {
                for (y = 0; y < c2; y++)
                {
                    c.setValues(a.mat[x][y] + b.mat[x][y]);
                }
            }
            c.setMatrix();
        }
        else
            Console.WriteLine("\n Matrices incompatible for addition. \n");

        Console.WriteLine(" Multiplying matrices a & b [c = a * b;]");
        
        c = new MatrixElement();                
        if (c1 == r2)
        {
            c.setRow(r1);
            c.setCol(c2);

            for (x = 0; x < r1; x++)
            {                
                for (y = 0; y < c2; y++)
                {
                    int temp = 0;

                    for (z = 0; z < c1; z++)
                    {
                        temp += a.mat[x][z] + b.mat[y][z];
                    }
                    c.setValues(temp);
                }
            }
            c.setMatrix();
        }
        else
            Console.WriteLine("\n Matrices incompatible for multiplication. \n");
        ///////////////////////////////////////////////////////////////////
        theprogram.RunEvalLoop();
      }
   
#endif


#if(TEST_MAIN2)

      public static void Main(String[] args)
      {
         Program theprogram = new Program();

         //first demonstrate visiting premade line.
         theprogram.VisitLine("myvar = 4 * 8;");
         theprogram.VisitLine("nvar = myvar - 3;");
         theprogram.VisitLine("print nvar;");
         
         int r1, r2, c1, c2, x, y, z;
         MatrixElement a, b, c;

        ///////////////////////////////////////////////////////////////////////
        a = new MatrixElement();
        a.setRow(1);
        a.setCol(2);
        r1 = a.getRow();
        c1 = a.getCol();
        a.setValues(5); a.setValues(2);
        Console.WriteLine("\n Matrix \"a\" with row = " + r1 + " column = " + c1);
        a.setMatrix();

        b = new MatrixElement();
        b.setRow(2);
        b.setCol(1);
        r2 = b.getRow();
        c2 = b.getCol();
        b.setValues(10); b.setValues(5);
        Console.WriteLine("\n Matrix \"b\" with row = " + r2 + " column = " + c2);
        b.setMatrix();

        Console.WriteLine(" Adding matrices a & b [c = a + b;]");
        
        c = new MatrixElement();        
        if (r1 == r2 && c1 == c2)
        {
            c.setRow(r1);
            c.setCol(c1);

            for (x = 0; x < r1; x++)
            {
                for (y = 0; y < c2; y++)
                {
                    c.setValues(a.mat[x][y] + b.mat[x][y]);
                }
            }
            c.setMatrix();
        }
        else
            Console.WriteLine("\n Matrices incompatible for addition. \n");

        Console.WriteLine(" Multiplying matrices a & b [c = a * b;]");
        
        c = new MatrixElement();        
        if (c1 == r2)
        {
            c.setRow(r1);
            c.setCol(c2);

            for (x = 0; x < r1; x++)
            {
                for (y = 0; y < c2; y++)
                {
                    int temp = 0;

                    for (z = 0; z < c1; z++)
                    {
                        temp += a.mat[x][z] * b.mat[z][y];
                    }
                    c.setValues(temp);
                }
            }
            c.setMatrix();
        }
        else
            Console.WriteLine("\n Matrices incompatible for multiplication. \n");
     
         theprogram.RunEvalLoop();
      }

#endif

    }
}
