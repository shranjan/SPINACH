////////////////////////////////////////////////////////////////////////
// AssignmentOperationElement.cs: holds the data needed for an 
//  assignment operation.
// 
// version: 1.0
// description: part of the interpreter example for the visitor design
//  pattern.
// author: Chetan Thawani (cthawani@syr.edu)
// source: phil pratt-szeliga (pcpratts@syr.edu)
// language: C# .Net 3.5
////////////////////////////////////////////////////////////////////////

// class for performing assignment operation involving elements of AST's
public class AssignmentOperationElement : Element {

  VariableElement mLhs; //left element is a variable element
  Element mRhs;  //right element

  //this function visits the assignment operation element of AST.
  public override void Accept(Visitor visitor){
    visitor.VisitAssignmentOperationElement(this);
  }
    //get the left hand side variable element
  public VariableElement getLhs() { return mLhs; }
    //set the lhs element
  public void setLhs(VariableElement lhs) { mLhs = lhs; }
    //get the right hand side element
  public Element getRhs() { return mRhs; }
    //set the right hand side element
  public void setRhs(Element rhs) { mRhs = rhs; }
}
