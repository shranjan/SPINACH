﻿////////////////////////////////////////////////////////////////////////
// MatrixElement.cs: holds the data needed for an 
//  assignment operation.
// 
// version: 1.0
// description: part of the interpreter example for the visitor design
//  pattern.
// author: Chetan Thawani (cthawani@syr.edu)
// source: phil pratt-szeliga (pcpratts@syr.edu)
// language: C# .Net 3.5
////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

public class MatrixElement : Element
{
    int row, col;
    VariableElement mLhs;
    Element mRhs;
    public List<int> values;
    public List<List<int>> mat;

    public MatrixElement()
    { 
        values = new List<int>();
        mat = new List<List<int>>();
    }

    public void setRow(int r)
    {
        //row = Int32.Parse(r.getText());
        row = r;
        Console.WriteLine(" row recvd = " + row);
    }

    public int getRow() { return row; }

    public void setCol(int c)
    {
        //col = Int32.Parse(c.getText());
        col = c;
        Console.WriteLine(" col recvd = " + col);
    }

    public int getCol() { return col; }

    public void setValues(int val)
    {
        //int v = Int32.Parse(val.getText());
        values.Add(val);
        Console.WriteLine(" value recvd = " + val);
    }

    public void setMatrix()
    {
        int x, y, i = 0;
        //Console.WriteLine("\n Matrix with row = " + row + " column = " + col);
        
        for (x = 0; x < row; x++)
        {            
            List<int> iv = new List<int>();
            for (y = 0; y < col; y++)
            {
                iv.Add(values[i]); 
                i++;
                Console.Write("  " + iv[y]);
            }
            mat.Add(iv); Console.WriteLine(" \n ");
        }
        Console.Write("\n");
    }

   



    public override void Accept(Visitor visitor)
    {
        visitor.VisitMatrixElement(this);
    }

    public VariableElement getLhs() { return mLhs; }
    public void setLhs(VariableElement lhs) { mLhs = lhs; }

    public Element getRhs() { return mRhs; }
    public void setRhs(Element rhs) { mRhs = rhs; }
}
