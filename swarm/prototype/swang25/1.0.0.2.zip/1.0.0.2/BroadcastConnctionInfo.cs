﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
namespace AsyncServerForm
{
    class SendSwarmInfo
    {

        public void UpdateSwarmInfo(Hashtable hs)
        {
            // Peer_Sender sender = null;
            StringBuilder sb = new StringBuilder();
            if (hs != null)
            {
                foreach (string IP in hs.Keys)
                {
                    ConnectionInfo conInfo = (ConnectionInfo)hs[IP];
                    int Prt = conInfo.Port;
                   // string IP = conInfo.IP;
                    string username = conInfo.UserName;
                    bool mast = conInfo.Master;
                    bool back = conInfo.BackUp;
                    string xport = "<port>" + Prt + "</port>";
                    string xIP = "<IP>" + IP + "</IP>";
                    string xusername = "<Username>" + username + "</Username>";
                    string Master = "<Master>" + mast + "</Master>";
                    string BackUp = "<BackUp>" + back + "</BackUp>";
                    sb.Append(xport);
                    sb.Append(",");
                    sb.Append(xIP);
                    sb.Append(",");
                    sb.Append(xusername);
                    sb.Append(",");
                    sb.Append(Master);
                    sb.Append(",");
                    sb.Append(BackUp);
                    sb.Append(":");

                }

                foreach (string IP in hs.Keys)
                {
                    ConnectionInfo conInfo = (ConnectionInfo)hs[IP];
                    int port = conInfo.Port;
                    AsynchronousClient cl = new AsynchronousClient();

                    if (sb != null)
                    {
                        cl.BroadCast(IP, port, sb.ToString());
                    }
                }

            }
        }

    }


}

