﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Threading;

namespace AsyncServerForm
{
    public partial class AsynchronousSocketListener
    {

        public String parseMsg(String msg)
        {
            String type=" ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                type = elem.Attributes().ElementAt(0).Value;

            if (type == "Connection")
                getConnectionRequestMsg(msg);
            else if (type == "IPtoPeer")
                getIPtoPeerMsg(msg);
            //else if (type == "HeartBeatRequest")
            //    getHeartBeatRequest(ref mPeer);
            //else if (type == "HeartBeatReply")
            //    getmsgHeartBeatReply();
            else if (type == "Master")
                getMasterMsg(msg);
            else if (type == "Backup")
                getBackupMsg(msg);
            //else if (type == "Run")
            //    getRun(ref mPeer);
            //else if (type == "RunSucess")
            //    getRunSucess();
            //else if (type == "RunFail")
            //    getRunFail();
            //else if (type == "ReRun")
            //    getReRun(ref mPeer);
            else if (type == "Chat")
                getChatMsg();

            return type;
                                
        }

        public void getConnectionRequestMsg(String msg)
        {
            String ip;
            String port;
            String name;
            String cpu;
            Thread t1 = null;
            Thread t2 = null;
            Thread t3 = null;

            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Elements("root").Descendants()
                    select x;
            foreach (var elem in q)
            {
                ip = elem.Attributes().ElementAt(0).Value;
                port = elem.Attributes().ElementAt(1).Value;
                name = elem.Attributes().ElementAt(2).Value;
                cpu = elem.Attributes().ElementAt(3).Value;
                InsertPeer(ip, port, name, cpu);
                if (IPtoPeer.Count == 2)
                    SetBackup(ip + ":" + port);

                MessageGenerator temp = new MessageGenerator();
                string mMsg = temp.msgIPtoPeer(IPtoPeer);
                string master = temp.msgMaster(GetMaster());
                string backup = temp.msgBackup(GetBackup());
                AsynchronousClient client1 = new AsynchronousClient();
                client1.SetMultiMsg(IPtoPeer, mMsg, mPeer.mIP + ":" + mPeer.mPort);
                t1 = new Thread(new ThreadStart(client1.SendMultiClient));
                t1.Start();
                t1.IsBackground = true;
                AsynchronousClient client2 = new AsynchronousClient();
                client2.SetSingleMsg(ip,port, master);
                t2 = new Thread(new ThreadStart(client2.SendSingleClient));
                t2.Start();
                t2.IsBackground = true;
                AsynchronousClient client3 = new AsynchronousClient();
                client3.SetSingleMsg(ip, port, backup);
                t3 = new Thread(new ThreadStart(client3.SendSingleClient));
                t3.Start();
                t3.IsBackground = true;
            }
            showTable();
        }
        public void getIPtoPeerMsg(String msg)
        {
            String ip;
            String port;
            String name;
            String cpu;

            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Elements("root").Descendants()
                    select x;
            foreach (var elem in q)
            {
                ip = elem.Attributes().ElementAt(0).Value;
                port = elem.Attributes().ElementAt(1).Value;
                name = elem.Attributes().ElementAt(2).Value;
                cpu = elem.Attributes().ElementAt(3).Value;
                InsertPeer(ip, port, name, cpu);
            }
            showTable();
        }
        //public void getHeartBeatRequest(ref Peer mPeer) 
        //{
        //    String ipport = mPeer.GetIP() + mPeer.GetPort();
        //    string smsg = mMsg.msgHeartBeatReply(ipport);

        //}

        //public void getmsgHeartBeatReply() { }
        public void getMasterMsg(String msg)
        {
            string master = " ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                master = elem.Value;
            SetMaster(master);
            showTable();
        }

        public void getBackupMsg(String msg)
        {
            string backup = " ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                backup = elem.Value;
            SetBackup(backup);
            showTable();
        }

        //public void getRun(ref Peer mPeer) 
        //{
        //    string temp;
        //    string ipport = mPeer.GetIP() + mPeer.GetPort();
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //    temp = mPeer.GetFlag(pid);

        //    if (temp == "0")
        //    {
        //        mPeer.SetFlag(pid, "1");
        //        string smsg = mMsg.msgRunSucessReply(pid,ipport);
        //    }
        //    else
        //    {
        //        string smsg = mMsg.msgRunFailReply(pid, ipport);
        //    }
        //}

        //public void getRunFail()
        //{
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //}

        //public void getRunSucess()
        //{
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //}

        //public void getReRun(ref Peer mPeer)
        //{
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //    mPeer.SetFlag(pid, "0");
        //}

        public void getChatMsg() 
        {
            //string backup = " ";
            //XDocument xml = XDocument.Parse(msg);
            //var q = from x in xml.Descendants()
            //        where (x.Name == "root")
            //        select x;
            //foreach (var elem in q)
            //    backup = elem.Value;
            //SetBackup(backup);
        }
        public void showTable()
        {
            foreach (Object ip in IPtoPeer.Keys)
            {
                Peer mPeer = (Peer)IPtoPeer[ip];
                Console.Write("{0} ---> IP:{1},Port:{2},Name:{3},CPU:{4}\n", 
                    ip, mPeer.mIP, mPeer.mPort, mPeer.mName, mPeer.mCPU);
            }
            Console.Write("Master: {0} ; Backup: {1}\n", GetMaster(), GetBackup());
        }
    }
}
