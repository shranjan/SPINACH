﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace AsyncServerForm
{
    //class ProgramInfo
    //{ }
    public struct Peer
    {
        public String mIP;
        public String mPort;
        public String mName;
        public String mCPU;
    }

    public struct Heartbeat
    {
        public String SendTime;
        public String ReceiveTime;
    }

    public partial class AsynchronousSocketListener
    {
        //connection part
        Peer mPeer = new Peer();

        //computation part
        //private Hashtable RunFlag = new Hashtable();//pid->runflag
        //private Hashtable Program = new Hashtable();//pid->swarm program object

        //shared infomation part
        private String Master;
        private String Backup;
        private Hashtable IPtoPeer=new Hashtable();//ip:port->peer object
        private Hashtable NametoIP=new Hashtable();//username->ip:port
        private Hashtable IPtoHeartbeat = new Hashtable();//ip:port->heartbeat object

        public void SetIP(String str) { mPeer.mIP = str; }
        public String GetIP() { return mPeer.mIP; }

        public void SetPort(String str) { mPeer.mPort = str; }
        public String GetPort() { return mPeer.mPort; }

        public void SetName(String str) { mPeer.mName = str; }
        public String GetName() { return mPeer.mName; }

        public void SetCPU(String str) { mPeer.mCPU = str; }
        public String GetCPU() { return mPeer.mCPU; }

        //public void SetFlag(String pid,String flag) 
        //{
        //    RunFlag[pid] = flag;
        //}
        //public String GetFlag(String pid) 
        //{
        //    if(RunFlag.Contains(pid))
        //        return RunFlag[pid].ToString();
        //    else
        //        return "-1";
        //}

        public void SetMaster(String str) { Master = str; }
        public String GetMaster() { return Master; }

        public void SetBackup(String str) { Backup = str; }
        public String GetBackup() { return Backup; }

        public int InsertPeer(String ip, String port, String name, String cpu)
        {
            string ipport = ip + ":" + port;
            Peer nPeer=new Peer();
            nPeer.mIP=ip;
            nPeer.mPort=port;
            nPeer.mName=name;
            nPeer.mCPU=cpu;
            IPtoPeer[ipport] = nPeer;
            NametoIP[name] = ipport;
            return 1;
        }

        public int RemovePeer(String ip, String port)
        {
            string ipport = ip + ":" + port;
            if (IPtoPeer.Contains(ipport))
            {
                Peer temp = (Peer)IPtoPeer[ipport];
                string name = temp.mName;
                IPtoPeer.Remove(ipport);
                if(NametoIP.Contains(name))
                    NametoIP.Remove(name);
                return 1;
            }
            else
                return 0;
        }

        public Hashtable GetIPtoPeer() { return IPtoPeer; }
        public Hashtable GetNametoIP() { return NametoIP; }

        //public void InsertProg(String pid, ref ProgramInfo prog) 
        //{
        //    Program[pid] = prog;
        //}
        //public int RemoveProg(String pid) { return 0; }
        //public ProgramInfo GetProg(String pid) { return null; }
        //public int CheckRun(String pid)
        //{
        //    return 0;
        //}

        //public String ProgOwner(String pid) { return "owner"; }
        //public int ReadAccess(String pid) { return 0; }
        //public int WriteAccess(String pid) { return 0; }
    }
}
