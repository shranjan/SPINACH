﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;

namespace AsyncServerForm
{
    public partial class Form1 : Form
    {
        Thread t = null;
        AsynchronousSocketListener mSocket = new AsynchronousSocketListener();
        static IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
        static IPAddress SrcIp = ipHostInfo.AddressList[0];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string Username = "Peer1";
            string SrcPort = "11000";
            string cpu = "1";
            mSocket.SetIP(SrcIp.ToString());
            mSocket.SetPort(SrcPort);
            mSocket.SetName(Username);
            mSocket.SetCPU(cpu);
            
            
            try
            {
                t = new Thread(new ThreadStart(mSocket.StartListening));
                t.Start();
                t.IsBackground = true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        private void Connection_Request(object sender, EventArgs e)
        {
            mSocket.InsertPeer(mSocket.GetIP(), mSocket.GetPort(), mSocket.GetName(), mSocket.GetCPU());
            MessageGenerator msg = new MessageGenerator();
            string DstIp = textBox1.Text;
            string DstPort = textBox2.Text;
            string mMsg = msg.msgConnectionRequest(mSocket.GetIPtoPeer());

            AsynchronousClient client = new AsynchronousClient();
            client.SendSingleClient(DstIp, Int32.Parse(DstPort),mMsg);
            this.button1.Enabled = false;
            this.button2.Enabled = false;
            this.button3.Enabled = true;
        }

        private void Create_Swarm(object sender, EventArgs e)
        {;
            mSocket.InsertPeer(mSocket.GetIP(),mSocket.GetPort(), mSocket.GetName(), mSocket.GetCPU());
            mSocket.SetMaster(mSocket.GetIP() + ":" + mSocket.GetPort());
            this.button1.Enabled = false;
            this.button2.Enabled = false;
            this.button3.Enabled = true;
            

        }

        private void Send_ChatMsg(object sender, EventArgs e)
        {
            MessageGenerator mMsg = new MessageGenerator();
            string msg = mMsg.msgChat(this.richTextBox1.Text);
            AsynchronousClient client = new AsynchronousClient();
            client.SetMultiMsg(mSocket.GetIPtoPeer(), msg, mSocket.GetIP() + ":" + mSocket.GetPort());
            t = new Thread(new ThreadStart(client.SendMultiClient));
            t.Start();
            t.IsBackground = true;

            //m.HandleChatMessages("Peer1", richTextBox1.Text);
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //private void button4_Click(object sender, EventArgs e)
        //{
        //    MessageGenerator mg = new MessageGenerator();
        //    //string msg = mg.msgHeartBeatRequest(mSocket.GetIP() + ":" + mSocket.GetPort());
        //    string msg = mg.msgIPNameCPU(ref mSocket);

        //    AsynchronousSocketListener m = new AsynchronousSocketListener(mSocket.GetName(), msg);
        //    t = new Thread(new ThreadStart(m.BroadCastMessage));
        //    t.Start();
        //    t.IsBackground = true;
        //}
    }
}
