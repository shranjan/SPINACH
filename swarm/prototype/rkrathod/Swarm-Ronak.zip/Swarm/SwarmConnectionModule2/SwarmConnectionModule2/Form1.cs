﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Collections;
using System.Threading;


namespace SwarmConnectionModule2
{
    public partial class Form1 : Form
    {

        Peer_Listner tcpl = null;
        XmlDocument deqStr;
        XmlNode objNode;
        Thread tlisten = null;
        Peer_Sender c = null;
        ArrayList a = new ArrayList();
        // bool connect = true;
        bool remoteprocessing = false;
        public static void displayerror(String err)
        {
            MessageBox.Show(err);
        }

        public Form1()
        {
            InitializeComponent();
            Q.myQ = new Queue();
        }
        private void load()
        {
            listBox1.Items.Clear();
            string MessageString = null;
            deqStr = new XmlDocument();
            if (remoteprocessing)
            {
                String str = (String)Q.myQ.Dequeue();
                deqStr.LoadXml(str);
                objNode = deqStr.DocumentElement;
                string tagName = objNode.Name;
                if (tagName == "mch")
                {
                    MessageString = objNode.InnerText;
                    richTextBox2.Text = MessageString;
                }
                else if (tagName == "mhd")
                {
                    string XmlStr = objNode.InnerText;
                    string[] si = XmlStr.Split(':');
                    string info = si.ToString();

                    for (int i = 0; i < si.Length; i++)
                    {
                        if (si.Length == 1)
                        {
                            listBox1.Items.Add(si[0]);
                        }
                        else
                        {
                            listBox1.Items.Add(si[i]);
                        }
                    }
                    //Hashtable hd = Deserialize(SerializedStr);




                }
                else
                {
                    MessageString = objNode.InnerText;
                    textBox4.Text = MessageString;
                }
            }
        }

        private void Connect_Request(object sender, EventArgs e)
        {
            c = new Peer_Sender(textBox1.Text, Int32.Parse(textBox2.Text));
            c.Connect(textBox1.Text, Int32.Parse(textBox2.Text), "127.0.0.1", 8002, "Zutao");
           // MessageBox.Show("Client2 has connected to Prototype");
           
           
        }

        private void Transmit(object sender, EventArgs e)
        {
            string str = textBox3.Text;
            c.send(str);
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tcpl = new Peer_Listner();
            // tcpl.port = 2079;
            tlisten = new Thread(new ThreadStart(tcpl.listenproc));
            try
            {
                tlisten.Start();
                tlisten.IsBackground = true;
                //timer1.Start();
            }
            catch (Exception)
            {
                MessageBox.Show("another listener is using port");

            }    
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (Q.myQ.Count > 0)
            {
                remoteprocessing = true;
                load();
            }
        }

        private void SendChatMessages(object sender, EventArgs e)
        {
            string username = "Zutao";
            string ChatMessage=richTextBox1.Text;
            c.sendChatMessage(ChatMessage, username);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            c.send("sendhashtable");
        }
    }
}
