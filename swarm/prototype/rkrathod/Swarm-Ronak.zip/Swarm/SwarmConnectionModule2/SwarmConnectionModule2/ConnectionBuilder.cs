﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using System.Xml;

namespace SwarmConnectionModule2
{
    public struct Q
    {
        public static Queue myQ;
    }

    public class Peer_Sender
    {
        TcpClient clnt = null;
        Byte[] data;
        NetworkStream stream = null; //st = null;
        public Int32 port;
        public string IPAddress;
        //  FileInfo fi;
        // String fname;
        // BinaryReader br;

        public Peer_Sender()
        {
        }
        public Peer_Sender(string IP, Int32 tmpPort)
        {
            IPAddress = IP;
            port = tmpPort;
            // Connect();

        }


        public void Connect()
        {
            try
            {

                clnt = new TcpClient(IPAddress, port);
                data = new Byte[256];
                stream = clnt.GetStream();
               // MessageBox.Show("Two way connection established");
            }
            catch (Exception e)
            {
                SwarmConnectionModule2.Form1.displayerror("SocketException:" + e.Message);
            }

        }
        public void Connect(String DstIP, int DstPort, string SrcIP, int SrcPort, string Username)
        {
            try
            {

                clnt = new TcpClient(DstIP, DstPort);
                data = new Byte[256];
                stream = clnt.GetStream();
                // stream.Write(str);
                //  string endmessage = "<msg></msg>";
                string s = "<mcg>";
                string e = "</mcg>";
                string seperator = ",";
                data = System.Text.Encoding.ASCII.GetBytes(s);
                stream.Write(data, 0, s.Length);
                data = System.Text.Encoding.ASCII.GetBytes(SrcIP);
                stream.Write(data, 0, SrcIP.Length);
                data = System.Text.Encoding.ASCII.GetBytes(seperator);
                stream.Write(data, 0, seperator.Length);
                data = System.Text.Encoding.ASCII.GetBytes(SrcPort.ToString());
                stream.Write(data, 0, SrcPort.ToString().Length);
                data = System.Text.Encoding.ASCII.GetBytes(seperator);
                stream.Write(data, 0, seperator.Length);
                data = System.Text.Encoding.ASCII.GetBytes(Username);
                stream.Write(data, 0, Username.Length);
                data = System.Text.Encoding.ASCII.GetBytes(e);
                stream.Write(data, 0, e.Length);



            }
            catch (Exception e)
            {

                SwarmConnectionModule2.Form1.displayerror("SocketException:" + e.Message);
            }
        }

        public void send(String str)
        {
            try
            {
                string s2 = "<msg>" + str + "</msg>";
                data = System.Text.Encoding.ASCII.GetBytes(s2);
                stream.Write(data, 0, data.Length);
            }
            catch (Exception e)
            {
                SwarmConnectionModule2.Form1.displayerror("SocketException: " + e.Message);
                //Console.WriteLine("SocketException: {0}", e);
            }

        }
        public void sendChatMessage(string str,string un)
        {
            try
            {
                string s2 = "<mch>"+un+":"+ str + "</mch>";
                data = System.Text.Encoding.ASCII.GetBytes(s2);
                stream.Write(data, 0, data.Length);
            }
            catch (Exception e)
            {
                SwarmConnectionModule2.Form1.displayerror("SocketException: " + e.Message);
                //Console.WriteLine("SocketException: {0}", e);
            }

        }

        public void disconnect()
        {
            try
            {
                clnt.Close();
            }
            catch (Exception e)
            {
                SwarmConnectionModule2.Form1.displayerror("SocketException: " + e.Message);

                //Console.WriteLine("SocketException: {0}", e);
            }

        }

    }
    class Peer_Handler
    {
        Peer_Sender sender = null;
        Socket recvsocket = null;
        StringBuilder msg = null;
        String completemsg = "";
        ArrayList msges = new ArrayList();
        XmlDocument deqStr;
        XmlNode objNode;
        string SrcIP = null;
        int SrcPort = 0;
        string SrcP = null;
        string Username;

        public Peer_Handler(Socket cln)
        {
            recvsocket = cln;
        }
        public string GetMessage()
        {
            msg = new StringBuilder();
            byte[] buffer = new byte[1];
            char ch = ' ';
            const string end1 = "</msg>";
            const string end2 = "</mcg>";
            const string end3 = "</mch>";
            const string end4 = "</mhd>";
            char[] cha = new char[5];
            int elen = end1.Length;
            int elen1 = end2.Length;
            int elen2 = end3.Length;
            int elen3 = end4.Length;
            //Message framing: read message one byte at a time, looking for
            //terminating characters "</msg>"
            Thread.Sleep(1000);
            while (true)
            {
                int bytesrecvd = recvsocket.Receive(buffer, 0, 1, 0);
                ch = (char)buffer[0];
                msg.Append(ch);

                if (msg.Length >= 5)
                {
                    string decide = msg.ToString();
                    string subs = decide.Substring(0, 5);
                    if (subs == "<mcg>")
                    {
                        int mlen1 = msg.Length;
                        bool matches1 = false;
                        for (int i = 0; i < elen1; ++i)
                        {
                            if ((msg[mlen1 - i - 1]) != (end2[elen1 - i - 1]))
                            {
                                matches1 = false;
                                break;
                            }
                            matches1 = true;
                        }
                        if (matches1)
                        {
                            this.DecodeConRequest(msg.ToString());
                            return "<msg></msg>";

                        }

                    }
                    else if (subs == "<msg>")
                    {

                        int mlen1 = msg.Length;
                        bool matches1 = false;
                        for (int i = 0; i < elen; ++i)
                        {
                            if ((msg[mlen1 - i - 1]) != (end1[elen - i - 1]))
                            {
                                matches1 = false;
                                break;
                            }
                            matches1 = true;
                        }
                        if (matches1)
                        {

                            return msg.ToString();

                        }


                    }
                    else if (subs == "<mhd>")
                    {

                        int mlen1 = msg.Length;
                        bool matches1 = false;
                        for (int i = 0; i < elen; ++i)
                        {
                            if ((msg[mlen1 - i - 1]) != (end4[elen3 - i - 1]))
                            {
                                matches1 = false;
                                break;
                            }
                            matches1 = true;
                        }
                        if (matches1)
                        {

                            return msg.ToString();

                        }


                    }
                    else
                    {
                        int mlen1 = msg.Length;
                        bool matches1 = false;
                        for (int i = 0; i < elen1; ++i)
                        {
                            if ((msg[mlen1 - i - 1]) != (end3[elen2 - i - 1]))
                            {
                                matches1 = false;
                                break;
                            }
                            matches1 = true;
                        }
                        if (matches1)
                        {
                            //this.ChatMessages(msg.ToString());

                            return msg.ToString();

                        }

                    }

                }

                int mlen = msg.Length;
                // bool matches = false;
                if (mlen < elen)
                {
                    continue;
                }

            }
        }
        public void Handlemsg()
        {
            //Form1 f = new Form1();
            try
            {

                while (completemsg != "<msg>quit</msg>")
                {
                    completemsg = this.GetMessage();
                    if ((completemsg != "<msg></msg>" || completemsg!=" "))
                    {
                        Q.myQ.Enqueue(completemsg);


                    }
                    else
                        break;
                }


            }
            catch (Exception e)
            {

                // f.displayerror(e.Message);
                SwarmConnectionModule2.Form1.displayerror(e.Message);
            }
        }
        public void DecodeConRequest(string str)
        {
            string MessageString = null;
            deqStr = new XmlDocument();
            deqStr.LoadXml(str);
            objNode = deqStr.DocumentElement;
            MessageString = objNode.InnerText;
            string[] si = MessageString.Split(',');
            SrcIP = si[0];
            SrcP = si[1];
            SrcPort = Convert.ToInt32(SrcP);
            Username = si[2];
            sender = new Peer_Sender(SrcIP, SrcPort);
            sender.Connect();
            sender.send("[Message from 8002]");


        }
    }


    class Peer_Listner
    {

        TcpListener server = null;
        Thread clnhandler = null;
        public string currentmsg = "";
        public Int32 port = 8002;
        Peer_Handler cln;
       

        public void listenproc()
        {
           
            try
            {

                IPAddress localAddr = IPAddress.Parse("127.0.0.1");
                // Int32 port = 2500;
                this.server = new TcpListener(localAddr, port);
                this.server.Start();
            }
            catch (Exception ex)
            {
                SwarmConnectionModule2.Form1.displayerror(ex.Message);
            }
            while (true)
            {
                // Peer_Handler cln;
       
                try
                {

                    Socket clnSocket = server.AcceptSocket();
                    cln = new Peer_Handler(clnSocket);
                    clnhandler = new Thread(new ThreadStart(cln.Handlemsg));
                    clnhandler.Start();
                    clnhandler.IsBackground = true;
                    Thread.Sleep(1000);
                
              
       

                }
                catch (Exception ex)
                {

                    SwarmConnectionModule2.Form1.displayerror(ex.Message);
                    break;
                }



            }
            if (clnhandler != null)
                clnhandler.Abort();
        }

        public void release()
        {
            clnhandler.Abort();
        }
        public void disconnect()
        {
            server.Stop();

        }
    }






}


