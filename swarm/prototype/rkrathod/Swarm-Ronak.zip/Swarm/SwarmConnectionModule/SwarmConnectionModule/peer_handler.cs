﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using System.Xml;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Timers;

namespace SwarmConnectionModule
{
    [Serializable]
    public class Peer_Handler
    {

        Peer_Sender sender = null;
        Socket recvsocket = null;
        StringBuilder msg = null;
        String completemsg = "";
        XmlDocument deqStr;
        XmlNode objNode;
        string SrcIP = null;
        int SrcPort = 0;
        string SrcP = null;
        string Username;
        public static Hashtable hash = new Hashtable();
        Peer_Chat peer_chat = null;
        SendSwarmInfo swi = null;

        public Peer_Handler()
        {
          //  peer_chat = new Peer_Chat();
        }
        public Peer_Handler(Socket cln)
        {
            recvsocket = cln;
            peer_chat = new Peer_Chat();
            swi = new SendSwarmInfo();
        }
        public string GetMessage()
        {
            msg = new StringBuilder();
            byte[] buffer = new byte[1];
            char ch = ' ';
            const string end1 = "</msg>";
            const string end2 = "</mcg>";
            const string end3 = "</mch>";
            char[] cha = new char[5];
            int elen = end1.Length;
            int elen1 = end2.Length;
            int elen2 = end3.Length;
            //Message framing: read message one byte at a time, looking for
            //terminating characters "</msg>"
            Thread.Sleep(1000);
            while (true)
            {
                int bytesrecvd = recvsocket.Receive(buffer, 0, 1, 0);
                ch = (char)buffer[0];
                msg.Append(ch);

                if (msg.Length >= 5)
                {
                    string decide = msg.ToString();
                    string subs = decide.Substring(0, 5);
                    if (subs == "<mcg>")
                    {
                        int mlen1 = msg.Length;
                        bool matches1 = false;
                        for (int i = 0; i < elen1; ++i)
                        {
                            if ((msg[mlen1 - i - 1]) != (end2[elen1 - i - 1]))
                            {
                                matches1 = false;
                                break;
                            }
                            matches1 = true;
                        }
                        if (matches1)
                        {
                            this.DecodeConRequest(msg.ToString());
                            return "<msg></msg>";

                        }

                    }
                    else if (subs == "<msg>")
                    {

                        int mlen1 = msg.Length;
                        bool matches1 = false;
                        for (int i = 0; i < elen; ++i)
                        {
                            if ((msg[mlen1 - i - 1]) != (end1[elen - i - 1]))
                            {
                                matches1 = false;
                                break;
                            }
                            matches1 = true;
                        }
                        if (matches1)
                        {

                            return msg.ToString();

                        }


                    }
                    else
                    {
                        int mlen1 = msg.Length;
                        bool matches1 = false;
                        for (int i = 0; i < elen1; ++i)
                        {
                            if ((msg[mlen1 - i - 1]) != (end3[elen2 - i - 1]))
                            {
                                matches1 = false;
                                break;
                            }
                            matches1 = true;
                        }
                        if (matches1)
                        {
                            this.ChatMessages(msg.ToString());
                            
                            return "<msg></msg>";

                        }

                    }

                }

                int mlen = msg.Length;
                // bool matches = false;
                if (mlen < elen)
                {
                    continue;
                }

            }
        }
        public void Handlemsg()
        {
            //Form1 f = new Form1();
            try
            {

                while (completemsg != "<msg>quit</msg>")
                {
                    completemsg = this.GetMessage();
                    if (completemsg == "<msg>sendhashtable</msg>")
                    {
                        swi.UpdateSwarmInfo(hash);
                    }
                    else
                    {
                        if ((completemsg != "<msg></msg>" || completemsg != " "))
                        {
                            Q.myQ.Enqueue(completemsg);


                        }

                        else
                            break;
                    }
                }


            }
            catch (Exception e)
            {

                // f.displayerror(e.Message);
                SwarmConnectionModule.Form1.displayerror(e.Message);
            }
        }
        public void DecodeConRequest(string str)
        {
            string MessageString = null;
            deqStr = new XmlDocument();
            deqStr.LoadXml(str);
            objNode = deqStr.DocumentElement;
            MessageString = objNode.InnerText;
            string[] si = MessageString.Split(',');
            SrcIP = si[0];
            SrcP = si[1];
            SrcPort = Convert.ToInt32(SrcP);
            Username = si[2];
            sender = new Peer_Sender(SrcIP, SrcPort);
            sender.Connect();
            sender.send("[Message from 8000]");

            hash.Add(SrcPort, new ConnectionInfo(SrcIP, Username));
           // HashToXml(hash);
            //StartTimer();
            //string hst=SendHashTableToPeers(hash);
            //sender.sendHashedConnectionInfo(hst);




        }
       
        //public void HashToXml(Hashtable hx)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    foreach (int port in hx.Keys)
        //    {
        //        ConnectionInfo conInfo = (ConnectionInfo)hx[port];
        //        int Prt = port;
        //        string IP = conInfo.ip;
        //        string username = conInfo.username;
        //        string xport = "<port>"+Prt+"</port>";
        //        string xIP = "<IP>"+IP+"</IP>";
        //        string xusername = "<Username>"+username+"</Username>";
        //        sb.Append(xport);
        //        sb.Append(",");
        //        sb.Append(xIP);
        //        sb.Append(",");
        //        sb.Append(xusername);
        //        sb.Append(":");

        //    }
        //    sender.sendHashedConnectionInfo(sb.ToString());
        //}
        public void ChatMessages(string str)
        {
            //Peer_Chat a = new Peer_Chat();
            //a.AcceptChatMessages(str);
            //SendConnectionInfo(hash);
            peer_chat.AcceptChatMessages(str);
            SendConnectionInfo();
            
        }
        public void SendConnectionInfo()
        {
            //Peer_Chat a = new Peer_Chat();
            //a.AcceptConnectionInfo(hash);
            peer_chat.AcceptConnectionInfo(hash);
        }
        public void StartTimer()
        {
            System.Timers.Timer tim = new System.Timers.Timer();
            tim.Elapsed += new ElapsedEventHandler(OnTime);
            tim.Interval = 20000;
            tim.Enabled = true;


        }
        public static void OnTime(object source, ElapsedEventArgs e)
        {
            SendSwarmInfo sw = new SendSwarmInfo();
            sw.UpdateSwarmInfo(hash);
        }

        
       
        //public string SendHashTableToPeers(Hashtable hs)
        //{
        //    BinaryFormatter bf = new BinaryFormatter();
        //    MemoryStream ms = new MemoryStream();
        //    //FileStream fs = new FileStream("Datafile.dat", FileMode.Create);
        //    try
        //    {
        //        bf.Serialize(ms, hs);
        //        return Convert.ToBase64String(ms.ToArray());
        //    }
        //    catch (Exception ex)
        //    {
        //        //MessageBox.Show(ex.Message.ToString());
        //        return string.Empty;
        //    }
        //    finally
        //    {
        //        ms.Close();
        //    }
            
        //}


    }
}
