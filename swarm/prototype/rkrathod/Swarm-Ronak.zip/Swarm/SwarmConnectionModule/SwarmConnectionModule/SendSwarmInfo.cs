﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
namespace SwarmConnectionModule
{
    class SendSwarmInfo
    {
       

        public void UpdateSwarmInfo(Hashtable hs)
        {
            Peer_Sender sender = null;
            StringBuilder sb = new StringBuilder();
            if(hs != null)
            {
            foreach (int port in hs.Keys)
            {
                ConnectionInfo conInfo = (ConnectionInfo)hs[port];
                int Prt = port;
                string IP = conInfo.ip;
                string username = conInfo.username;
                string xport = "<port>"+Prt+"</port>";
                string xIP = "<IP>"+IP+"</IP>";
                string xusername = "<Username>"+username+"</Username>";
                sb.Append(xport);
                sb.Append(",");
                sb.Append(xIP);
                sb.Append(",");
                sb.Append(xusername);
                sb.Append(":");
                
            }
           
            foreach (int Port in hs.Keys)
            {
                ConnectionInfo conInfo = (ConnectionInfo)hs[Port];
                string IP = conInfo.ip;
                sender = new Peer_Sender(IP, Port);
                sender.Connect();
                //sender.send(chatMsg);
                if (sb != null)
                {
                    sender.sendHashedConnectionInfo(sb.ToString());
                }
                sender.disconnect();
                Thread.Sleep(1000);


            }

         }
      }
    
   }


    }

