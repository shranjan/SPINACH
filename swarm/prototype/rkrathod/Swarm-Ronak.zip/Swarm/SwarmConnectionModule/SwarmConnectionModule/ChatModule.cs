﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;


namespace SwarmConnectionModule
{
    class Peer_Chat
    {
        Peer_Sender sender = null;
        bool receivedMsg = false;
        string chatMsg = "";
        
        public void AcceptChatMessages(string str)
        {
            chatMsg = str;
            receivedMsg = true;    
        }
        public void AcceptConnectionInfo(Hashtable hs)
        {
            if (receivedMsg == true)
            {
                receivedMsg = false;
                foreach (int Port in hs.Keys)
                {
                    ConnectionInfo conInfo = (ConnectionInfo)hs[Port];
                    string IP = conInfo.ip;
                    sender = new Peer_Sender(IP, Port);
                    sender.Connect();
                    //sender.send(chatMsg);
                    sender.sendChatToPeer(chatMsg);

                    Thread.Sleep(1000);
                }
            }
            sender.disconnect();
        }

        
    }
}
