﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Threading;
using System.Collections;

namespace SwarmConnectionModule
{
    public partial class Form1 : Form
    {

        Peer_Listner tcpl = null;
        XmlDocument deqStr;
        XmlNode objNode;
        Thread tlisten = null;
        Peer_Sender c = null;
        ArrayList a= new ArrayList();
        // bool connect = true;
        bool remoteprocessing = false;
        Peer_Handler ph = null;
       
      

        public static void displayerror(String err)
        {
            MessageBox.Show(err);
        }

        public Form1()
        {
            InitializeComponent();
            Q.myQ=new Queue();

        }
        private void load()
        {
           
            string MessageString = null;
            deqStr = new XmlDocument();
            if (remoteprocessing)
            {
                String str = (String)Q.myQ.Dequeue();
                deqStr.LoadXml(str);
                objNode = deqStr.DocumentElement;
                MessageString = objNode.InnerText;
                textBox4.Text = MessageString;
            }
            
        }
        private void Connect_Request(object sender, EventArgs e)
        {
            c = new Peer_Sender(textBox1.Text, Int32.Parse(textBox2.Text));
            c.Connect(textBox1.Text, Int32.Parse(textBox2.Text), "127.0.0.1", 8000, "Rathod");
           // c.send("Hello");
          //  MessageBox.Show("Client2 has connected to Prototype");
           
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tcpl = new Peer_Listner();
            // tcpl.port = 2079;
            tlisten = new Thread(new ThreadStart(tcpl.listenproc));
            try
            {
                tlisten.Start();
                tlisten.IsBackground = true;
                //timer1.Start();
            }
            catch (Exception)
            {
                MessageBox.Show("another listener is using port");

            }    
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (Q.myQ.Count > 0)
            {
                remoteprocessing = true;
                load();
            }
        }

       
        private void button2_Click(object sender, EventArgs e)
        {
            string str = textBox3.Text;
          
            c.send(str);
           
        }

        //private void Update_Hash(object sender, EventArgs e)
        //{
        //    ph = new Peer_Handler();
        //    ph.SendSwarmInfo();
        //}

        

    }
}
