﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Collections;
using System.Xml;


namespace ClientToClient2
{
    public partial class Form1 : Form
    {
       
        MyTcpListener tcpl = null;
        XmlDocument deqStr;
        XmlNode objNode;
        Thread tlisten = null;
        client cl = null;
       // bool connect = true;
        bool remoteprocessing = false;
        public Form1()
        {
            InitializeComponent();
            Q.myQ = new Queue();
        }
        public static void displayerror(String err)
        {
            MessageBox.Show(err);
        }


        private void load()
        {
            string MessageString = null;
            deqStr = new XmlDocument();
            if (remoteprocessing)
            {
                String str = (String)Q.myQ.Dequeue();
                deqStr.LoadXml(str);
                objNode = deqStr.DocumentElement;
                MessageString = objNode.InnerText;
                textBox4.Text = MessageString;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            tcpl = new MyTcpListener();
           // tcpl.port = 2079;
            tlisten = new Thread(new ThreadStart(tcpl.listenproc));
            try
            {
                tlisten.Start();
                tlisten.IsBackground = true;
                //timer1.Start();
            }
            catch (Exception)
            {
                MessageBox.Show("another listener is using port");

            }    

        }

        private void Connect(object sender, EventArgs e)
        {
            //if (connect)
            //{
            //    connect = true;
                cl = new client(textBox1.Text, Int32.Parse(textBox2.Text));
                //cl.IPAddress = textBox1.Text;
                //cl.port = Int32.Parse(textBox2.Text);
                cl.Connect();
                MessageBox.Show("Client2 has connected to Prototype");
                cl.send("127.0.0.1,2078");
            //}
            //else
            //{
            //    connect = false;
            //    cl.disconnect();
            //    MessageBox.Show("Remote view deactivated");
            //}

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str = textBox3.Text;
            if (cl != null)
            {
                cl.send(str);
            }
            else
            {
                MessageBox.Show("Connection not established");
            }
        }

        //private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        //{
        //    tlisten.Abort();
        //    tcpl.release();
        //    tlisten = null;
        //    tcpl = null;
        //}

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Q.myQ.Count > 0)
            {
                remoteprocessing = true;
                load();
            }
        }


    }
}
