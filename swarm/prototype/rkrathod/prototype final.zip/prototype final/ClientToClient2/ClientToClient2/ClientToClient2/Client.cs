﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;
using System.Collections;

namespace ClientToClient2
{
    public struct Q
    {
        public static Queue myQ;
    }

    public class client
    {
        TcpClient clnt = null;
        Byte[] data;
        NetworkStream stream = null; //st = null;
        public Int32 port;
        public string IPAddress;
        //  FileInfo fi;
        // String fname;
        // BinaryReader br;
       
        public client(string IP, Int32 tmpPort)
        {
            IPAddress = IP;
            port = tmpPort;
        }


        public void Connect()
        {
            try
            {
                // Create a TcpClient.
                // Note, for this client to work you need to have a TcpServer
                // connected to the same address as specified by the server, port
                // combination.
                ///Int32 port = 2500
                //IPAddress localAddr = IPAddress.Parse("127.0.0.1");
                clnt = new TcpClient(IPAddress, port);
                data = new Byte[256];
                stream = clnt.GetStream();
            }
            catch (Exception e)
            {
                ClientToClient2.Form1.displayerror("SocketException:" + e.Message);
            }

        }
        public void Connect(String str)
        {
            try
            {
                // Create a TcpClient.
                // Note, for this client to work you need to have a TcpServer
                // connected to the same address as specified by the server, port
                // combination.
                ///Int32 port = 2500;
                //IPAddress localAddr = IPAddress.Parse("127.0.0.1");
                clnt = new TcpClient("127.0.0.1", port);
                data = new Byte[256];
                stream = clnt.GetStream();
                // stream.Write(str);
                data = System.Text.Encoding.ASCII.GetBytes(str);
                stream.Write(data, 0, str.Length);
            }
            catch (Exception e)
            {

                ClientToClient2.Form1.displayerror("SocketException:" + e.Message);
            }
        }

        public void send(String str)
        {
            try
            {
                string s2 = "<msg>" + str + "</msg>";
                data = System.Text.Encoding.ASCII.GetBytes(s2);
                stream.Write(data, 0, data.Length);
            }
            catch (Exception e)
            {
                ClientToClient2.Form1.displayerror("SocketException: " + e.Message);
                //Console.WriteLine("SocketException: {0}", e);
            }

        }

        public void disconnect()
        {
            try
            {
                clnt.Close();
            }
            catch (Exception e)
            {
                ClientToClient2.Form1.displayerror("SocketException: " + e.Message);

                //Console.WriteLine("SocketException: {0}", e);
            }

        }

    }
    class clienthandler
    {
        Socket recvsocket = null;
        StringBuilder msg = null;
        String completemsg = "";

        public clienthandler(Socket cln)
        {
            recvsocket = cln;
        }
        public string GetMessage()
        {
            msg = new StringBuilder();
            byte[] buffer = new byte[1];
            char ch = ' ';
            const string end = "</msg>";
            int elen = end.Length;
            //Message framing: read message one byte at a time, looking for
            //terminating characters "</msg>"
            while (true)
            {
                int bytesrecvd = recvsocket.Receive(buffer, 0, 1, 0);
                ch = (char)buffer[0];
                msg.Append(ch);

                int mlen = msg.Length;
                bool matches = false;
                if (mlen < elen)
                {
                    continue;
                }
                for (int i = 0; i < elen; ++i)
                {
                    if ((msg[mlen - i - 1]) != (end[elen - i - 1]))
                    {
                        matches = false;
                        break;
                    }
                    matches = true;
                }
                if (matches)
                {
                    return msg.ToString();
                }

            }
        }
        public void Handlemsg()
        {
            //Form1 f = new Form1();
            try
            {

                while (completemsg != "quit")
                {
                    completemsg = this.GetMessage();
                    if ((completemsg != " "))
                    {
                        Q.myQ.Enqueue(completemsg);

                    }
                }
            }
            catch (Exception e)
            {

                // f.displayerror(e.Message);
                ClientToClient2.Form1.displayerror(e.Message);
            }
        }
    }


   class MyTcpListener
    {

        TcpListener server = null;
        Thread clnhandler = null;
        public string currentmsg = "";
        public Int32 port = 8000;


        public void listenproc()
        {
            try
            {

              IPAddress localAddr = IPAddress.Parse("127.0.0.1");
                // Int32 port = 2500;
                this.server = new TcpListener(localAddr, port);
                this.server.Start();
            }
            catch (Exception ex)
            {
                ClientToClient2.Form1.displayerror(ex.Message);
            }
            while (true)
            {
                clienthandler cln;
                try
                {

                    Socket clnSocket = server.AcceptSocket();
                    cln = new clienthandler(clnSocket);
                    clnhandler = new Thread(new ThreadStart(cln.Handlemsg));
                    clnhandler.Start();
                    clnhandler.IsBackground = true;

                }
                catch (Exception ex)
                {

                    ClientToClient2.Form1.displayerror(ex.Message);
                    break;
                }



            }
            if (clnhandler != null)
                clnhandler.Abort();
        }

        public void release()
        {
            clnhandler.Abort();
        }
        public void disconnect()
        {
            server.Stop();

        }
    }






}


