﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using System.Xml;

namespace SwarmConnectionModule
{
  
   
    public struct Q
    {
        public static Queue myQ;
    }
    [Serializable]
    public struct ConnectionInfo
    {
        public string ip;
        public string username;

        public ConnectionInfo(string s1,string s2)
        {
            ip = s1;
            username = s2;
        }

        

    }
   

    public class Peer_Sender
    {
       
        TcpClient clnt = null;
        Byte[] data;
        NetworkStream stream = null; //st = null;
        public Int32 port;
        public string IPAddress;
        //  FileInfo fi;
        // String fname;
        // BinaryReader br;

        public Peer_Sender()
        {
        }
        public Peer_Sender(string IP, Int32 tmpPort)
        {
            IPAddress = IP;
            port = tmpPort;
           // Connect();
          
        }


        public void Connect()
        {
            try
            {
             
                clnt = new TcpClient(IPAddress, port);
                data = new Byte[256];
                stream = clnt.GetStream();
               // MessageBox.Show("Two way connection established");
            }
            catch (Exception e)
            {
                SwarmConnectionModule.Form1.displayerror("SocketException:" + e.Message);
            }

        }
        public void Connect(String DstIP, int DstPort, string SrcIP, int SrcPort, string Username)
        {
            try
            {

                clnt = new TcpClient(DstIP, DstPort);
                data = new Byte[256];
                stream = clnt.GetStream();
                // stream.Write(str);
                //  string endmessage = "<msg></msg>";
                string s = "<mcg>";
                string e = "</mcg>";
                string seperator = ",";
                data = System.Text.Encoding.ASCII.GetBytes(s);
                stream.Write(data, 0, s.Length);
                data = System.Text.Encoding.ASCII.GetBytes(SrcIP);
                stream.Write(data, 0, SrcIP.Length);
                data = System.Text.Encoding.ASCII.GetBytes(seperator);
                stream.Write(data, 0, seperator.Length);
                data = System.Text.Encoding.ASCII.GetBytes(SrcPort.ToString());
                stream.Write(data, 0, SrcPort.ToString().Length);
                data = System.Text.Encoding.ASCII.GetBytes(seperator);
                stream.Write(data, 0, seperator.Length);
                data = System.Text.Encoding.ASCII.GetBytes(Username);
                stream.Write(data, 0, Username.Length);
                data = System.Text.Encoding.ASCII.GetBytes(e);
                stream.Write(data, 0, e.Length);



            }
            catch (Exception e)
            {

                SwarmConnectionModule.Form1.displayerror("SocketException:" + e.Message);
            }
        }

        public void send(String str)
        {
            try
            {
                string s2 = "<msg>" + str + "</msg>";
                data = System.Text.Encoding.ASCII.GetBytes(s2);
                stream.Write(data, 0, data.Length);
            }
            catch (Exception e)
            {
                SwarmConnectionModule.Form1.displayerror("SocketException: " + e.Message);
                //Console.WriteLine("SocketException: {0}", e);
            }

        }
        public void sendChatToPeer(string str)
        {
            data = System.Text.Encoding.ASCII.GetBytes(str);
            stream.Write(data, 0, data.Length);
        }
        public void sendHashedConnectionInfo(string str)
        {
            string st = "<mhd>" + str + "</mhd>";
            data = System.Text.Encoding.ASCII.GetBytes(st);
            stream.Write(data, 0, data.Length);
        }

        public void disconnect()
        {
            try
            {
                clnt.Close();
            }
            catch (Exception e)
            {
                SwarmConnectionModule.Form1.displayerror("SocketException: " + e.Message);

                //Console.WriteLine("SocketException: {0}", e);
            }

        }

    }
   


    class Peer_Listner
    {

        TcpListener server = null;
        Thread clnhandler = null;
        public string currentmsg = "";
        public Int32 port = 8000;
        Peer_Handler cln;


        public void listenproc()
        {
            try
            {

                IPAddress localAddr = IPAddress.Parse("127.0.0.1");
                // Int32 port = 2500;
                this.server = new TcpListener(localAddr, port);
                this.server.Start();
            }
            catch (Exception ex)
            {
                SwarmConnectionModule.Form1.displayerror(ex.Message);
            }
            while (true)
            {
            

               // Peer_Handler cln;
                try
                {

                    Socket clnSocket = server.AcceptSocket();
                    cln = new Peer_Handler(clnSocket);
                    clnhandler = new Thread(new ThreadStart(cln.Handlemsg));
                    clnhandler.Start();
                    clnhandler.IsBackground = true;
                    Thread.Sleep(1000);
                 

                }
                catch (Exception ex)
                {

                    SwarmConnectionModule.Form1.displayerror(ex.Message);
                    break;
                }



            }
            if (clnhandler != null)
                clnhandler.Abort();
        }

        public void release()
        {
            clnhandler.Abort();
        }
        public void disconnect()
        {
            server.Stop();

        }
    }






}


