﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Collections;
using System.Xml;

namespace ClientToClientPrototype
{
    public partial class Form1 : Form
    {
        clienthandler ch;
        XmlDocument deqStr;
        XmlNode objNode;
        MyTcpListener tcpl=null;
        Thread tlisten = null;
        client cl = null;
        bool connect = false;
        bool remoteprocessing = false;
        public static void displayerror(String err)
        {
            MessageBox.Show(err);
        }

        public Form1()
        {
            InitializeComponent();
            Q.myQ = new Queue();
        }

       
        private void Form1_Load(object sender, EventArgs e)
        {

            tcpl = new MyTcpListener();
            ch = new clienthandler();
           // tcpl.port = 2078;
            tlisten = new Thread(new ThreadStart(tcpl.listenproc));
            try
            {
                tlisten.Start();
                tlisten.IsBackground = true;
                //timer1.Start();
                //string msg = ch.GetMessage();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            



        }

        private void Connect(object sender, EventArgs e)
        {
            if (!connect)
            {
                connect = true;
                cl = new client();
                cl.IPAddress =textBox1.Text;
                cl.port = Int32.Parse( textBox2.Text);
                cl.Connect();
                MessageBox.Show("Prototype has connected to client2");
            }
            else
            {
                connect = false;
                cl.disconnect();
                MessageBox.Show("Remote view deactivated");
            }

            
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Q.myQ.Count > 0)
            {
                remoteprocessing = true;
                load();
            }
        }
        private void load()
        {
            string MessageString=null;
            deqStr = new XmlDocument();
            if (remoteprocessing)
            {
                String str = (String)Q.myQ.Dequeue();
                deqStr.LoadXml(str);
                objNode = deqStr.DocumentElement;
                MessageString = objNode.InnerText;
                textBox4.Text = MessageString;
            }
        }
        private void Transmit_Click(object sender, EventArgs e)
        {
            string str = textBox3.Text;
            if (cl == null)
            {
                MessageBox.Show("ClientProtype is not connected");
            }
            else
            {
                cl.send(str);
            }
            //tcpl.listenproc();
        }

        //private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        //{
        //    tcpl.release();
        //    tlisten.Abort();
            
        //    tcpl = null;
        //    tlisten = null;
        //    cl = null;
        //}

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            if (Q.myQ.Count > 0)
            {
                remoteprocessing = true;
                load();
            }
        }

       
        
        
    }
}
